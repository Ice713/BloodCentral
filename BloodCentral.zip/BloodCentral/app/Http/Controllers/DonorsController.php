<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;


class DonorsController extends Controller
{
    public function addDonor(Request $request){
        $check = DB::table('donors_personal_data')->where('blood_donor_number', $request->input('blood_donor_number'))->first();

        if ($check) {
            return 2;
        } else{
                $save = DB::table('donors_personal_data')->insert([
                'blood_donor_number' => $request->input('blood_donor_number'),
                'donor_surname' => $request->input('donor_surname'),
                'donor_firstname' => $request->input('donor_firstname'),
                'donor_midname' => $request->input('donor_midname'),
                'donor_birthdate' => $request->input('donor_birthdate'),
                'donor_age' => $request->input('donor_age'),
                'donor_civilstatus' => $request->input('donor_civilstatus'),
                'donor_sex' => $request->input('donor_sex'),
                'donor_add_no' => $request->input('donor_add_no'),
                'donor_add_st' => $request->input('donor_add_st'),
                'donor_add_brgy' => $request->input('donor_add_brgy'),
                'donor_add_town' => $request->input('donor_add_town'),
                'donor_add_prov_cit' => $request->input('donor_add_prov_cit'),
                'donor_add_zip' => $request->input('donor_add_zip'),
                'donor_offadd' => $request->input('donor_offadd'),
                'donor_nationality' => $request->input('donor_nationality'),
                'donor_religion' => $request->input('donor_religion'),
                'donor_education' => $request->input('donor_education'),
                'donor_occupation' => $request->input('donor_occupation'),
                'donor_contact_tel' => $request->input('donor_contact_tel'),
                'donor_contact_mobile' => $request->input('donor_contact_mobile'),
                'donor_contact_email' => $request->input('donor_contact_email'),
            ]);

            return $save ? 1 : 0;
        }
    }
}
