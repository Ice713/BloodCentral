<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;

class ManagementController extends Controller
{
    public function index(){
        return view('management/index');
    }

    public function donors(){
        return view('management/donors');
    }
}
