<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BloodCentral</title>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

    <!-- Tailwind CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- FontAwesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <!-- SweetAlert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="side-panel">
    <nav class="navbar navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">BloodCentral - Management</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Menu</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
                <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?php echo e(url('management/')); ?>">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Blood Management</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Blogs and News</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Blood Community
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark">
                    <li><a class="dropdown-item" href="<?php echo e(url('management/donors')); ?>">Blood Donors</a></li>
                    <li><a class="dropdown-item" href="#">Blood Requesters/Recipients</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="#">Blood Donation Shedule</a></li>
                    </ul>
                </li>
                </ul>
                <form class="d-flex mt-3" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-success" type="submit">Search</button>
                </form>
            </div>
            </div>
        </div>
        </nav>
    </div>
    <?php echo $__env->yieldContent('content'); ?>

    <!-- Include jQuery first, if needed -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Include Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- <script src="<?php echo e(url('public/assets/js/donors.js')); ?>"></script> -->

    <!-- Sweet Alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        // add donor
        $(document).on('submit', '#add-donor-form', function(e) {
            e.preventDefault(); // prevent page refresh after form submission
            // alert("Success");

            var pword1 = $('#pass').val();
            var pword2 = $('#repass').val();

            if(pword1 != pword2) {
                // alert('Password does not match');
                Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Password does not match'
                })
            } else if(pword1.length < 8 || pword1.length > 12) {
                // alert('Password should be 8 to 12 characters.');
                Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Password should be 8 to 12 characters.'
                })
            } else {
                //submit the data             
                $.ajax({
                    url: "add-donor", // url to be routed
                    method: "POST",
                    data: $('#add-donor-form').serialize(),
                    beforeSend:function(){
                        $("btn-add-donor").attr('disabled', 'true');
                    },
                    success:function(data) {
                        if (data == 2) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Donor record already exists!'
                        })
                        } else if(data == 1) {
                            // alert("Account successfully saved!");
                            $('#add-donor-form')[0].reset(); // clear the form
                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                text: 'Donor information successfully added!'
                            })
                        } else {
                            // alert("Account could not be saved!");
                            Swal.fire({
                                icon: 'error',
                                title: 'Error!',
                                text: 'Donor information could not be saved. Please try again later!'
                            })
                        }
                    }
                });    
            }  
        });
            

        $(document).ready(function (){
            // show add new blog post modal
            $(document).on('change', '#donor_birthdate', function(e) {
                // Get the entered birthdate value from the input field
                var birthdateValue = $('#donor_birthdate').val();

                // Calculate the age based on the entered birthdate
                var today = new Date();
                var birthdate = new Date(birthdateValue);
                var age = today.getFullYear() - birthdate.getFullYear();
                var monthDiff = today.getMonth() - birthdate.getMonth();
                if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthdate.getDate())) {
                    age--;
                }


                $('#donor_age').val(age);
            });

            $('#birthdate').tooltip();

        });


 

    </script>

    <!-- <script src="<?php echo e(asset('public\assets\js\donors.js')); ?>"></script> -->
    
</body>
</html><?php /**PATH D:\xampp\htdocs\Laravel\BloodCentral\resources\views/management/layout.blade.php ENDPATH**/ ?>