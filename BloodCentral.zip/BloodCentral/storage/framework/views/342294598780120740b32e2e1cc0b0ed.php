
<?php $__env->startSection('content'); ?>



<div class="container">
    <h1>Hello World</h1>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\BloodCentral\resources\views//index.blade.php ENDPATH**/ ?>