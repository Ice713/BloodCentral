
<?php $__env->startSection('content'); ?>

<!-- <main class="container">
    <h1 class="mt-20 text-2xl font-semibold">Profile</h1>
</main> -->

<div class="container flex  justify-center items-center h-screen">
    <div class="card w-full lg:w-1/2" id="login-donor-card">
        <div class="card-header">
            <h1 class="font-semibold text-2xl text-center">Management Profile</h1>
        </div>
        <div class="card-body">
            <div class="flex flex-col justify-center items-center">
                <button style="background-image: url('https://scontent.fcrk2-2.fna.fbcdn.net/v/t39.30808-6/360133272_1715505195552136_403153104994258334_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeHvD43Rv1oBfVypSZap2tAuFhh7zAL-YmIWGHvMAv5iYm7MjYP9bsEd76LtSST9JzuCdW2OQrjQnevcK_5Asr_i&_nc_ohc=E1VsyVdz4q8AX-eCZjJ&_nc_ht=scontent.fcrk2-2.fna&oh=00_AfDz3Ogf5SnWDpMNczb9VLktQrNHJA4TyTGonpuKyDbnzQ&oe=64D00724');" alt="Temporary profile" class="rounded-full w-40 h-40 bg-cover bg-center"></button>
                <h1 class="font-black text-4xl my-3"><?php echo e(Session::get('medtech_firstname')); ?> <?php echo e(Session::get('medtech_surname')); ?></h1>
                <h2 class="font-semibold text-slate-500 text-xl"><?php echo e(Session::get('medtech_username')); ?> | <?php echo e(Session::get('medtech_id_number')); ?></h2>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('management/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\BloodCentral\resources\views/management/profile.blade.php ENDPATH**/ ?>