
<?php $__env->startSection('content'); ?>

<main class="container">
    <h1 class="mt-20 text-2xl font-semibold">Dashboard</h1>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('management/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\BloodCentral\resources\views/management/login-management.blade.php ENDPATH**/ ?>