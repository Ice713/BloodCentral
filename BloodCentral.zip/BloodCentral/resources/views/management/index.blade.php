@extends('management/layout')
@section('content')

<main class="container">
    <h1 class="mt-20 text-2xl font-semibold">Dashboard</h1>
</main>

@endsection
