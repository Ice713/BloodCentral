@extends('layout')
@section('content')

<div class="container">
    <h1>Hello World</h1>
</div>

@endsection