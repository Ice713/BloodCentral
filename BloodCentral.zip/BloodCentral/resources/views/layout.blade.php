<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BloodCentral</title>

    <meta name="csrf-token" content="{{ csrf_token() }}">


    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

    <!-- Tailwind CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- FontAwesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- SweetAlert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<div class="side-panel">
    <nav class="navbar navbar-dark bg-red-700 sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">BloodCentral</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="offcanvas offcanvas-end  bg-red-950" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title text-white" id="offcanvasDarkNavbarLabel">Menu</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
                <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="{{url('/')}}">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{url('/login-donor')}}">Login as Donor</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Login as Blood Requester</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Blood Community
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark">
                    <li><a class="dropdown-item" href="#">Blood Donation News</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="{{ url('management/donors')}}">Blood Donation Calendar</a></li>
                    <li><a class="dropdown-item" href="#">Blood Donation Map</a></li>
                    </ul>
                </li>
                </ul>
                <form class="d-flex mt-3" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-success" type="submit">Search</button>
                </form>
            </div>
            </div>
        </div>
        </nav>
    </div>
    
    @yield('content')

    <!-- Include jQuery first, if needed -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Include Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function (){
            $('#register-donor-card').hide();

            $(document).on('click', '#register-here', function(){
                $('#login-donor-card').hide();
                $('#register-donor-card').show();
            });

            
            $(document).on('click', '#login-here', function(){
                $('#login-donor-card').show();
                $('#register-donor-card').hide();
            });

            $(document).on('change', '#donor_birthdate', function(e) {
                // Get the entered birthdate value from the input field
                var birthdateValue = $('#donor_birthdate').val();

                // Calculate the age based on the entered birthdate
                var today = new Date();
                var birthdate = new Date(birthdateValue);
                var age = today.getFullYear() - birthdate.getFullYear();
                var monthDiff = today.getMonth() - birthdate.getMonth();
                if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthdate.getDate())) {
                    age--;
                }


                $('#donor_age').val(age);
            });
        });

        //donor registration
        $(document).on('submit', '#donor-register-form', function(e) {
            e.preventDefault(); // prevent page refresh after form submission
            // alert("Success");
            var pword1 = $('#pass').val();
            var pword2 = $('#repass').val();

            if(pword1 != pword2) {
                // alert('Password does not match');
                Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Password does not match'
                })
            } else if(pword1.length < 8 || pword1.length > 12) {
                // alert('Password should be 8 to 12 characters.');
                Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Password should be 8 to 12 characters.'
                })
            } else {
                //submit the data            
                $.ajax({
                    url: "donor-register", // url to be routed
                    method: "POST",
                    data: $('#donor-register-form').serialize(),
                    beforeSend:function(){
                        $("btn-donor-register").attr('disabled', 'true');
                    },
                    success:function(data) {
                        if (data == 2) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Donor record already exists!'
                        })
                        } else if(data == 1) {
                            // alert("Account successfully saved!");
                            $('#donor-register-form')[0].reset(); // clear the form
                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                text: 'Donor information successfully added!'
                            })
                        } else {
                            // alert("Account could not be saved!");
                            Swal.fire({
                                icon: 'error',
                                title: 'Error!',
                                text: 'Donor information could not be saved. Please try again later!'
                            })
                        }
                    }
                }); 
            }     
        });
    </script>
</body>
</html>