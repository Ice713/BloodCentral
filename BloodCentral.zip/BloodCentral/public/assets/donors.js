// add donor
$(document).on('submit', '#add-donor-form', function(e) {
    e.preventDefault(); // prevent page refresh after form submission
    // alert("Success");

    var pword1 = $('#regpassword').val();
    var pword2 = $('#retyperegpassword').val();

    
    $.ajax({
        url: "add-donor", // url to be routed
        method: "POST",
        data: $('#add-donor-form').serialize(),
        beforeSend:function(){
            $("btn-add-donor").attr('disabled', 'true');
        },
        success:function(data) {
            if (data == 2) {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Donor record already exists!'
            })
            } else if(data == 1) {
                // alert("Account successfully saved!");
                $('#add-donor-form')[0].reset(); // clear the form
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: 'Donor information successfully added!'
                })
            } else {
                // alert("Account could not be saved!");
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Donor information could not be saved. Please try again later!'
                })
            }
        }
    });      
});
    
 
