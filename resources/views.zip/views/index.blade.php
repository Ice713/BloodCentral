@extends('header')
@section('content')

<div class="container">
    <h1 class="font-black mt-10 text-7xl">Blood<span class="text-red-600">Central</span> Homepage</h1>
</div>

@endsection